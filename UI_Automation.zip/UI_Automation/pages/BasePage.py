"""
All the common methods required for performing actions on the webPage are mentioned in the BasePage class.
1. Initialization of driver
2. Clicking on the webElement
3. Entering value in the webElement field
4. Getting text of the webElement
5. Getting value(attribute) from the webElement
6. Visibility of the webElement
7. Clearing existing values/data from the webElement field

"""

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from repository.objects import TestData


class BasePage:
    def __init__(self, driver):
        self.driver = driver

    def do_click(self, by_locator):
        WebDriverWait(self.driver,10).until(EC.visibility_of_element_located(by_locator)).click()

    def do_enter_value(self, by_locator, text):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).send_keys(text)

    def get_element_text(self, by_locator):
        element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
        return element.text

    def is_visible(self, by_locator):
        element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
        return bool(element)

    def get_element_value(self, by_locator):
        element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
        return element.get_attribute('value')

    def do_clear(self, by_locator):
        WebDriverWait(self.driver,10).until(EC.visibility_of_element_located(by_locator)).clear()

    def take_screenshot(self, image):
        self.driver.save_screenshot(TestData.Screenshot_dir + image + '.png')

