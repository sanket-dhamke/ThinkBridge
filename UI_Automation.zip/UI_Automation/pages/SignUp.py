"""
This class contains all the LoginPage related method definition and object paths for webElements on Login page.
This class extends BaseClass to use all the generic methods for performing webElement actions.
"""

from selenium.webdriver.common.by import By
from repository.objects import TestData
from pages.BasePage import BasePage
#from UI_Automation.repository.objects import TestData
#from UI_Automation.pages.BasePage import BasePage


class LoginPage(BasePage):
    Full_name = (By.ID, "name")
    Org_name = (By.ID, "orgName")
    Email = (By.ID, "singUpEmail")
    Agree = (By.XPATH, "//span[@class='black-color ng-binding']")
    Get_Started = (By.XPATH, "//div[@class='form-group custom-form-group']")
    Verify_email = (By.XPATH, "//div[@class='alert alert-danger alert-custom']")
    Dropdown = (By.XPATH, "//div[@placeholder='Choose Language']//span[@class='ui-select-match-text pull-left']")
    English = (By.XPATH, "//div[contains(text(),'English')]")
    Dutch = (By.XPATH, "//div[contains(text(),'Dutch')]")

    # Constructor of class

    def __init__(self, driver):
        super().__init__(driver)
        try:
            self.driver.get(TestData.Base_url)
        except:
            print("Invalid URL")
            assert False

    # Page actions

    def is_element_visible(self):
        print("Verify whether Forgot Password link is visible")
        self.do_click(self.Dropdown)
        print("Verification of English lanugage value from drop down", self.is_visible(self.English))
        print(self.is_visible(self.Dutch))

    def do_login(self, fullname, org, email):
        print("Performing login operation")
        self.do_click(self.Full_name)
        self.do_enter_value(self.Full_name, fullname)

        self.do_click(self.Org_name)
        self.do_enter_value(self.Org_name, org)

        self.do_click(self.Email)
        self.do_enter_value(self.Email, email)

        self.do_click(self.Agree)
        self.do_click(self.Get_Started)

        self.take_screenshot('sign-up')
        assert self.get_element_text(self.Verify_email) == TestData.Verify_message  # ERROR: Not able to change the user name"
