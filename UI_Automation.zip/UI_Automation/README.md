# **Automation Framework using pytest**

Using this automation framework user can sign up to the URL and verify the dropdown contents.

**Pre-requisites: **

1. Download and install python 3.8 or latest. Refer https://www.python.org/downloads/
2. Optional: Download and Install Integrated development environment such as Pycharm . Refer https://www.jetbrains.com/pycharm/
3. Must have chrome or firefox browser on the system.

**How to use: **
1. Unzip the zip file.
2. Go to project root location and open the command prompt type and execute below commands
		> pip install selenium
		> pip install webdriver-manager
		> pip install pytest-html
		> pip install pytest
3. Go to location /UI_Automation/repository/objects.py under the project root path.
4. Inside objects.py file user can provide value to key such as Url of application , Full name , browser name, organization name, Email and Verification message can even set the browser name where
   testcases will get executed.
				Base_url = "https://jt-dev.azurewebsites.net/#/SignUp"  # NOTE: Pass the url of the webPage.
				Full_Name = "sanket R dhamke"  # NOTE: Pass the Username for Login.
				Org_name = "PQWE"  # NOTE: Pass the Organization name.
				Browser = "chrome"  # NOTE: Pass "chrome" or "firefox" as per your choice.
				Email = "sanket.df@gmail.com"  # NOTE: Pass the Email id.
				Screenshot_dir = "D:/UI_Automation/screenshots/"  # NOTE: Pass absolute path of screenshot package
				Verify_message = "A welcome email has been sent. Please check your email."
			
		
    Edit the values as per the requirement.
	
5. Now run the following command on project root path.
        
		
	In case user want to run only login testcase then execute below command 
	    >python -m pytest -s -x .\tests\Login\test_SignUpPage.py --html=./reports/report.html >> .\logs\log.txt
	 
		
	Note: 
	 [1] Using '>>' operator we are copying console logs to log.txt file.
	 [2] '-s' is to capture the console output.
	 [3] '-x' will stop execution of automation on first failure. for example : url is invalid then it won't execute other testcases.
	 
6.  Post execution of the command verify html report which gets generated in /UI_Automation/reports/report.html 

7. 	Try to change object values in /UI_Automation/repository/objects.py and rerun the testcase.

** Framework Structure **

This framework is an implemenation of POM(Page Object Model) using pytest framework and selenium.

Folder structure:
				---UI_Automation
								>--pages
								
								>--reports
								
								>--repository
								
								>--tests
								        ->conftest.py
										->test_BasePage.py
								>--logs
								
								>--screenshots
								
								
	tests: All the executable testcases will be residing inside tests package .
	
	pages: All the method implementation for the testcases under tests package have been added into pages package.
	
	repository: This is the object repository for the automation framework which contains generic objects or elements and their actual values.
	
	reports: Post execution of the command mentioned in step 5 report will get generated in the reports package as a part of pytest-html plugin.
	
	logs: In this package log.txt will get generated and it will have the console logs.
	
	screenshots:  All screenshots will get stored inside screenshots package.
	
	conftest.py : 	conftest.py contains common fixtures required for all the automation testcases for their execution.
					Set the browser name in .UI_Automation/repository/repository.py and automation testcases will get executed in the respective browser.
					No need to download drivers for browser . IT will be downloaded automatically as per the browser.
					Tear down activity such as closing of browser will get executed post automation execution.
	
	test_BasePage.py : 	This file adds fixture from conftest.py file.
						All other test files need to inherit the BaseTest class from this file.
						
						
						
					
					
	