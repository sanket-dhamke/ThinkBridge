"""
Use fixture from conftest.py file.
All other test files need to inherit the BaseTest class from this file.

"""

import pytest


@pytest.mark.usefixtures("init_driver")
class BaseTest:
    pass
