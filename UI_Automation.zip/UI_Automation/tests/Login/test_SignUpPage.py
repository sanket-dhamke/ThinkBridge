"""
Declares flow of the sign up test scenario.
Internally this will execute methods defined in /pages/SignUp.py through /pages/BasePage(contains common methods)
"""

import pytest

from repository.objects import TestData
from pages.SignUp import LoginPage
from tests.test_BasePage import BaseTest


class TestLogin(BaseTest):

    def test_verify_dropdown_values(self):
        self.login_object = LoginPage(self.driver)
        self.login_object.is_element_visible()

    def test_enter_credentials(self):
        self.login_object = LoginPage(self.driver)
        self.login_object.do_login(TestData.Full_Name, TestData.Org_name, TestData.Email)
