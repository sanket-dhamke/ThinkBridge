"""
Object Repository for Automation Framework.
Use keys directly inside test execution files.
"""


class TestData:
    Base_url = "https://jt-dev.azurewebsites.net/#/SignUp"  # NOTE: Pass the url of the webPage.
    Full_Name = "sanket R dhamke"  # NOTE: Pass the Username for Login.
    Org_name = "PQWE"  # NOTE: Pass the Organization name.
    Browser = "chrome"  # NOTE: Pass "chrome" or "firefox" as per your choice.
    Email = "sanket.df@gmail.com"  # NOTE: Pass the Email id.
    Screenshot_dir = "D:/UI_Automation/screenshots/"  # NOTE: Pass absolute path of screenshot package
    Verify_message = "A welcome email has been sent. Please check your email."

